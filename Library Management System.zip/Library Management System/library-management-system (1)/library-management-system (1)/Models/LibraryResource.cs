using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace LibraryManagementSystem.Models
{
    public class LibraryResource
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [StringLength(200)]
        public string Title { get; set; } = string.Empty;

        [Required]
        [StringLength(100)]
        public string Author { get; set; } = string.Empty;

        [Required]
        public int PublicationYear { get; set; }

        [Required]
        [StringLength(50)]
        public string Genre { get; set; } = string.Empty;

        [Required]
        public ResourceType Type { get; set; }

        public bool IsAvailable { get; set; } = true;

        public DateTime? BorrowedDate { get; set; }

        public DateTime? DueDate { get; set; }

        [StringLength(100)]
        public string? BorrowerName { get; set; }

        [StringLength(15)]
        public string? BorrowerPhone { get; set; }

        public DateTime CreatedDate { get; set; } = DateTime.Now;

        public DateTime? UpdatedDate { get; set; }

        // Helper properties to safely display nullable fields
        [NotMapped]
        public string SafeBorrowerName => BorrowerName ?? string.Empty;

        [NotMapped]
        public string SafeBorrowerPhone => BorrowerPhone ?? string.Empty;

        [NotMapped]
        public string SafeDueDate => DueDate?.ToString("yyyy-MM-dd") ?? string.Empty;

        [NotMapped]
        public string SafeBorrowedDate => BorrowedDate?.ToString("yyyy-MM-dd") ?? string.Empty;
    }

    public enum ResourceType
    {
        Book,
        Journal,
        Media
    }
}
