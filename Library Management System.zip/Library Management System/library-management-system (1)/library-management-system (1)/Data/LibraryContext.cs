using Microsoft.EntityFrameworkCore;
using LibraryManagementSystem.Models;

namespace LibraryManagementSystem.Data
{
    public class LibraryContext : DbContext
    {
        public DbSet<LibraryResource> LibraryResources { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Server=DESKTOP-BCLIR7Q;Database=LibraryManagementDB;Trusted_Connection=True;Encrypt=False;");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<LibraryResource>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Title).IsRequired().HasMaxLength(200).HasDefaultValue(string.Empty);
                entity.Property(e => e.Author).IsRequired().HasMaxLength(100).HasDefaultValue(string.Empty);
                entity.Property(e => e.Genre).IsRequired().HasMaxLength(50).HasDefaultValue(string.Empty);
                entity.Property(e => e.BorrowerName).HasMaxLength(100).IsRequired(false);
                entity.Property(e => e.BorrowerPhone).HasMaxLength(15).IsRequired(false);
                entity.Property(e => e.IsAvailable).HasDefaultValue(true);
                entity.Property(e => e.CreatedDate).HasDefaultValueSql("GETDATE()");

                // Configure nullable properties explicitly
                entity.Property(e => e.BorrowedDate).IsRequired(false);
                entity.Property(e => e.DueDate).IsRequired(false);
                entity.Property(e => e.UpdatedDate).IsRequired(false);

                entity.HasIndex(e => e.Title);
                entity.HasIndex(e => e.Author);
                entity.HasIndex(e => e.Genre);
            });
        }
    }
}
