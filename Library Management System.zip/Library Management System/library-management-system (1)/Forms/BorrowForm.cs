using System;
using System.Drawing;
using System.Windows.Forms;

namespace LibraryManagementSystem.Forms
{
    public partial class BorrowForm : Form
    {
        public string BorrowerName { get; private set; }
        public string BorrowerPhone { get; private set; }
        public int LoanDays { get; private set; }
        
        private TextBox txtBorrowerName, txtBorrowerPhone;
        private NumericUpDown nudLoanDays;
        private Button btnBorrow, btnCancel;
        
        public BorrowForm()
        {
            InitializeComponent();
        }
        
        private void InitializeComponent()
        {
            this.Text = "Borrow Resource";
            this.Size = new Size(350, 200);
            this.StartPosition = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            
            // Borrower Name
            Label lblName = new Label
            {
                Text = "Borrower Name:",
                Location = new Point(20, 20),
                Size = new Size(100, 23)
            };
            
            txtBorrowerName = new TextBox
            {
                Location = new Point(130, 17),
                Size = new Size(180, 23)
            };
            
            // Borrower Phone
            Label lblPhone = new Label
            {
                Text = "Phone Number:",
                Location = new Point(20, 55),
                Size = new Size(100, 23)
            };
            
            txtBorrowerPhone = new TextBox
            {
                Location = new Point(130, 52),
                Size = new Size(180, 23)
            };
            
            // Loan Days
            Label lblDays = new Label
            {
                Text = "Loan Days:",
                Location = new Point(20, 90),
                Size = new Size(100, 23)
            };
            
            nudLoanDays = new NumericUpDown
            {
                Location = new Point(130, 87),
                Size = new Size(80, 23),
                Minimum = 1,
                Maximum = 365,
                Value = 14
            };
            
            // Buttons
            btnBorrow = new Button
            {
                Text = "Borrow",
                Location = new Point(155, 130),
                Size = new Size(75, 30),
                DialogResult = DialogResult.OK
            };
            btnBorrow.Click += BtnBorrow_Click;
            
            btnCancel = new Button
            {
                Text = "Cancel",
                Location = new Point(235, 130),
                Size = new Size(75, 30),
                DialogResult = DialogResult.Cancel
            };
            
            this.Controls.AddRange(new Control[] 
            {
                lblName, txtBorrowerName,
                lblPhone, txtBorrowerPhone,
                lblDays, nudLoanDays,
                btnBorrow, btnCancel
            });
            
            this.AcceptButton = btnBorrow;
            this.CancelButton = btnCancel;
        }
        
        private void BtnBorrow_Click(object sender, EventArgs e)
        {
            if (!ValidateInput())
                return;
            
            BorrowerName = txtBorrowerName.Text.Trim();
            BorrowerPhone = txtBorrowerPhone.Text.Trim();
            LoanDays = (int)nudLoanDays.Value;
        }
        
        private bool ValidateInput()
        {
            if (string.IsNullOrWhiteSpace(txtBorrowerName.Text))
            {
                MessageBox.Show("Borrower name is required", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtBorrowerName.Focus();
                return false;
            }
            
            if (string.IsNullOrWhiteSpace(txtBorrowerPhone.Text))
            {
                MessageBox.Show("Phone number is required", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtBorrowerPhone.Focus();
                return false;
            }
            
            return true;
        }
    }
}
