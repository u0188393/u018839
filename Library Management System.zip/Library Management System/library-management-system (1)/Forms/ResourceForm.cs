using System;
using System.Drawing;
using System.Windows.Forms;
using LibraryManagementSystem.Models;

namespace LibraryManagementSystem.Forms
{
    public partial class ResourceForm : Form
    {
        public LibraryResource Resource { get; private set; }
        
        private TextBox txtTitle, txtAuthor, txtYear, txtGenre;
        private ComboBox cmbType;
        private Button btnSave, btnCancel;
        private bool isEditMode;
        
        public ResourceForm(LibraryResource resource = null)
        {
            if (resource != null)
            {
                Resource = resource;
                isEditMode = true;
            }
            else
            {
                Resource = new LibraryResource();
                isEditMode = false;
            }
            
            InitializeComponent();
            
            if (isEditMode)
            {
                LoadResourceData();
            }
        }
        
        private void InitializeComponent()
        {
            this.Text = isEditMode ? "Edit Resource" : "Add Resource";
            this.Size = new Size(400, 300);
            this.StartPosition = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            
            // Title
            Label lblTitle = new Label
            {
                Text = "Title:",
                Location = new Point(20, 20),
                Size = new Size(80, 23)
            };
            
            txtTitle = new TextBox
            {
                Location = new Point(110, 17),
                Size = new Size(250, 23)
            };
            
            // Author
            Label lblAuthor = new Label
            {
                Text = "Author:",
                Location = new Point(20, 55),
                Size = new Size(80, 23)
            };
            
            txtAuthor = new TextBox
            {
                Location = new Point(110, 52),
                Size = new Size(250, 23)
            };
            
            // Publication Year
            Label lblYear = new Label
            {
                Text = "Year:",
                Location = new Point(20, 90),
                Size = new Size(80, 23)
            };
            
            txtYear = new TextBox
            {
                Location = new Point(110, 87),
                Size = new Size(100, 23)
            };
            
            // Genre
            Label lblGenre = new Label
            {
                Text = "Genre:",
                Location = new Point(20, 125),
                Size = new Size(80, 23)
            };
            
            txtGenre = new TextBox
            {
                Location = new Point(110, 122),
                Size = new Size(250, 23)
            };
            
            // Type
            Label lblType = new Label
            {
                Text = "Type:",
                Location = new Point(20, 160),
                Size = new Size(80, 23)
            };
            
            cmbType = new ComboBox
            {
                Location = new Point(110, 157),
                Size = new Size(150, 23),
                DropDownStyle = ComboBoxStyle.DropDownList
            };
            cmbType.Items.AddRange(new[] { "Book", "Journal", "Media" });
            cmbType.SelectedIndex = 0;
            
            // Buttons
            btnSave = new Button
            {
                Text = "Save",
                Location = new Point(200, 210),
                Size = new Size(75, 30),
                DialogResult = DialogResult.OK
            };
            btnSave.Click += BtnSave_Click;
            
            btnCancel = new Button
            {
                Text = "Cancel",
                Location = new Point(285, 210),
                Size = new Size(75, 30),
                DialogResult = DialogResult.Cancel
            };
            
            this.Controls.AddRange(new Control[] 
            {
                lblTitle, txtTitle,
                lblAuthor, txtAuthor,
                lblYear, txtYear,
                lblGenre, txtGenre,
                lblType, cmbType,
                btnSave, btnCancel
            });
            
            this.AcceptButton = btnSave;
            this.CancelButton = btnCancel;
        }
        
        private void LoadResourceData()
        {
            txtTitle.Text = Resource.Title;
            txtAuthor.Text = Resource.Author;
            txtYear.Text = Resource.PublicationYear.ToString();
            txtGenre.Text = Resource.Genre;
            cmbType.SelectedIndex = (int)Resource.Type;
        }
        
        private void BtnSave_Click(object sender, EventArgs e)
        {
            if (!ValidateInput())
                return;
            
            Resource.Title = txtTitle.Text.Trim();
            Resource.Author = txtAuthor.Text.Trim();
            Resource.PublicationYear = int.Parse(txtYear.Text);
            Resource.Genre = txtGenre.Text.Trim();
            Resource.Type = (ResourceType)cmbType.SelectedIndex;
            
            if (!isEditMode)
            {
                Resource.CreatedDate = DateTime.Now;
            }
            else
            {
                Resource.UpdatedDate = DateTime.Now;
            }
        }
        
        private bool ValidateInput()
        {
            if (string.IsNullOrWhiteSpace(txtTitle.Text))
            {
                MessageBox.Show("Title is required", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtTitle.Focus();
                return false;
            }
            
            if (string.IsNullOrWhiteSpace(txtAuthor.Text))
            {
                MessageBox.Show("Author is required", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtAuthor.Focus();
                return false;
            }
            
            if (!int.TryParse(txtYear.Text, out int year) || year < 1000 || year > DateTime.Now.Year + 1)
            {
                MessageBox.Show("Please enter a valid publication year", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtYear.Focus();
                return false;
            }
            
            if (string.IsNullOrWhiteSpace(txtGenre.Text))
            {
                MessageBox.Show("Genre is required", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtGenre.Focus();
                return false;
            }
            
            return true;
        }
    }
}
