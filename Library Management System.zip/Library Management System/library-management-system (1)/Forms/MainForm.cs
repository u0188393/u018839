using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using LibraryManagementSystem.Models;
using LibraryManagementSystem.Services;

namespace LibraryManagementSystem.Forms
{
    public partial class MainForm : Form
    {
        private LibraryService _libraryService;
        private DataGridView dgvResources;
        private TextBox txtSearch;
        private ComboBox cmbSearchType;
        private Button btnAdd, btnEdit, btnDelete, btnBorrow, btnReturn, btnReports;
        private StatusStrip statusStrip;
        private ToolStripStatusLabel lblStatus;
        
        public MainForm()
        {
            InitializeComponent();
            _libraryService = new LibraryService();
            LoadResources();
        }
        
        private void InitializeComponent()
        {
            this.Text = "Library Management System";
            this.Size = new Size(1200, 700);
            this.StartPosition = FormStartPosition.CenterScreen;
            
            // Create main panel
            Panel mainPanel = new Panel
            {
                Dock = DockStyle.Fill,
                Padding = new Padding(10)
            };
            
            // Search panel
            Panel searchPanel = new Panel
            {
                Height = 60,
                Dock = DockStyle.Top
            };
            
            Label lblSearch = new Label
            {
                Text = "Search:",
                Location = new Point(10, 15),
                Size = new Size(50, 23)
            };
            
            txtSearch = new TextBox
            {
                Location = new Point(70, 12),
                Size = new Size(200, 23)
            };
            txtSearch.TextChanged += TxtSearch_TextChanged;
            
            cmbSearchType = new ComboBox
            {
                Location = new Point(280, 12),
                Size = new Size(100, 23),
                DropDownStyle = ComboBoxStyle.DropDownList
            };
            cmbSearchType.Items.AddRange(new[] { "Title", "Author", "Genre" });
            cmbSearchType.SelectedIndex = 0;
            cmbSearchType.SelectedIndexChanged += CmbSearchType_SelectedIndexChanged;
            
            searchPanel.Controls.AddRange(new Control[] { lblSearch, txtSearch, cmbSearchType });
            
            // Button panel
            Panel buttonPanel = new Panel
            {
                Height = 50,
                Dock = DockStyle.Bottom
            };
            
            btnAdd = new Button
            {
                Text = "Add Resource",
                Location = new Point(10, 10),
                Size = new Size(100, 30)
            };
            btnAdd.Click += BtnAdd_Click;
            
            btnEdit = new Button
            {
                Text = "Edit Resource",
                Location = new Point(120, 10),
                Size = new Size(100, 30)
            };
            btnEdit.Click += BtnEdit_Click;
            
            btnDelete = new Button
            {
                Text = "Delete Resource",
                Location = new Point(230, 10),
                Size = new Size(100, 30)
            };
            btnDelete.Click += BtnDelete_Click;
            
            btnBorrow = new Button
            {
                Text = "Borrow",
                Location = new Point(340, 10),
                Size = new Size(80, 30)
            };
            btnBorrow.Click += BtnBorrow_Click;
            
            btnReturn = new Button
            {
                Text = "Return",
                Location = new Point(430, 10),
                Size = new Size(80, 30)
            };
            btnReturn.Click += BtnReturn_Click;
            
            btnReports = new Button
            {
                Text = "Reports",
                Location = new Point(520, 10),
                Size = new Size(80, 30)
            };
            btnReports.Click += BtnReports_Click;
            
            buttonPanel.Controls.AddRange(new Control[] { btnAdd, btnEdit, btnDelete, btnBorrow, btnReturn, btnReports });
            
            // DataGridView
            dgvResources = new DataGridView
            {
                Dock = DockStyle.Fill,
                AutoGenerateColumns = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false,
                ReadOnly = true,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false
            };
            
            SetupDataGridViewColumns();
            
            // Status strip
            statusStrip = new StatusStrip();
            lblStatus = new ToolStripStatusLabel("Ready");
            statusStrip.Items.Add(lblStatus);
            
            // Add controls to main panel
            mainPanel.Controls.Add(dgvResources);
            mainPanel.Controls.Add(searchPanel);
            mainPanel.Controls.Add(buttonPanel);
            
            this.Controls.Add(mainPanel);
            this.Controls.Add(statusStrip);
        }
        
        private void SetupDataGridViewColumns()
        {
            dgvResources.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Id",
                HeaderText = "ID",
                Width = 50
            });
            
            dgvResources.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Title",
                HeaderText = "Title",
                Width = 200
            });
            
            dgvResources.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Author",
                HeaderText = "Author",
                Width = 150
            });
            
            dgvResources.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "PublicationYear",
                HeaderText = "Year",
                Width = 80
            });
            
            dgvResources.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Genre",
                HeaderText = "Genre",
                Width = 100
            });
            
            dgvResources.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Type",
                HeaderText = "Type",
                Width = 80
            });
            
            dgvResources.Columns.Add(new DataGridViewCheckBoxColumn
            {
                DataPropertyName = "IsAvailable",
                HeaderText = "Available",
                Width = 80
            });
            
            dgvResources.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "BorrowerName",
                HeaderText = "Borrower",
                Width = 120
            });
            
            dgvResources.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "DueDate",
                HeaderText = "Due Date",
                Width = 100
            });
        }
        
        private void LoadResources()
        {
            try
            {
                var resources = _libraryService.GetAllResources();
                dgvResources.DataSource = resources;
                lblStatus.Text = $"Loaded {resources.Count} resources";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading resources: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        
        private void TxtSearch_TextChanged(object sender, EventArgs e)
        {
            PerformSearch();
        }
        
        private void CmbSearchType_SelectedIndexChanged(object sender, EventArgs e)
        {
            PerformSearch();
        }
        
        private void PerformSearch()
        {
            if (string.IsNullOrWhiteSpace(txtSearch.Text))
            {
                LoadResources();
                return;
            }
            
            try
            {
                var searchResults = cmbSearchType.SelectedItem.ToString() switch
                {
                    "Title" => _libraryService.SearchByTitle(txtSearch.Text),
                    "Author" => _libraryService.SearchByAuthor(txtSearch.Text),
                    "Genre" => _libraryService.SearchByGenre(txtSearch.Text),
                    _ => _libraryService.GetAllResources()
                };
                
                dgvResources.DataSource = searchResults;
                lblStatus.Text = $"Found {searchResults.Count} resources";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error searching: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        
        private void BtnAdd_Click(object sender, EventArgs e)
        {
            using (var form = new ResourceForm())
            {
                if (form.ShowDialog() == DialogResult.OK)
                {
                    if (_libraryService.AddResource(form.Resource))
                    {
                        LoadResources();
                        lblStatus.Text = "Resource added successfully";
                    }
                    else
                    {
                        MessageBox.Show("Failed to add resource", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }
        
        private void BtnEdit_Click(object sender, EventArgs e)
        {
            if (dgvResources.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a resource to edit", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            
            var selectedResource = (LibraryResource)dgvResources.SelectedRows[0].DataBoundItem;
            
            using (var form = new ResourceForm(selectedResource))
            {
                if (form.ShowDialog() == DialogResult.OK)
                {
                    if (_libraryService.UpdateResource(form.Resource))
                    {
                        LoadResources();
                        lblStatus.Text = "Resource updated successfully";
                    }
                    else
                    {
                        MessageBox.Show("Failed to update resource", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }
        
        private void BtnDelete_Click(object sender, EventArgs e)
        {
            if (dgvResources.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a resource to delete", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            
            var selectedResource = (LibraryResource)dgvResources.SelectedRows[0].DataBoundItem;
            
            if (MessageBox.Show($"Are you sure you want to delete '{selectedResource.Title}'?", "Confirm Delete", 
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                if (_libraryService.DeleteResource(selectedResource.Id))
                {
                    LoadResources();
                    lblStatus.Text = "Resource deleted successfully";
                }
                else
                {
                    MessageBox.Show("Failed to delete resource", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        
        private void BtnBorrow_Click(object sender, EventArgs e)
        {
            if (dgvResources.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a resource to borrow", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            
            var selectedResource = (LibraryResource)dgvResources.SelectedRows[0].DataBoundItem;
            
            if (!selectedResource.IsAvailable)
            {
                MessageBox.Show("This resource is already borrowed", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            
            using (var form = new BorrowForm())
            {
                if (form.ShowDialog() == DialogResult.OK)
                {
                    if (_libraryService.BorrowResource(selectedResource.Id, form.BorrowerName, form.BorrowerPhone, form.LoanDays))
                    {
                        LoadResources();
                        lblStatus.Text = "Resource borrowed successfully";
                    }
                    else
                    {
                        MessageBox.Show("Failed to borrow resource", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }
        
        private void BtnReturn_Click(object sender, EventArgs e)
        {
            if (dgvResources.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a resource to return", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            
            var selectedResource = (LibraryResource)dgvResources.SelectedRows[0].DataBoundItem;
            
            if (selectedResource.IsAvailable)
            {
                MessageBox.Show("This resource is not currently borrowed", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            
            if (MessageBox.Show($"Return '{selectedResource.Title}'?", "Confirm Return", 
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                if (_libraryService.ReturnResource(selectedResource.Id))
                {
                    LoadResources();
                    lblStatus.Text = "Resource returned successfully";
                }
                else
                {
                    MessageBox.Show("Failed to return resource", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        
        private void BtnReports_Click(object sender, EventArgs e)
        {
            using (var form = new ReportsForm(_libraryService))
            {
                form.ShowDialog();
            }
        }
        
        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            _libraryService?.Dispose();
            base.OnFormClosed(e);
        }
    }
}
