using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using LibraryManagementSystem.Services;

namespace LibraryManagementSystem.Forms
{
    public partial class ReportsForm : Form
    {
        private LibraryService _libraryService;
        private TabControl tabControl;
        private DataGridView dgvOverdue, dgvStatistics;
        
        public ReportsForm(LibraryService libraryService)
        {
            _libraryService = libraryService;
            InitializeComponent();
            LoadReports();
        }
        
        private void InitializeComponent()
        {
            this.Text = "Library Reports";
            this.Size = new Size(800, 600);
            this.StartPosition = FormStartPosition.CenterParent;
            
            tabControl = new TabControl
            {
                Dock = DockStyle.Fill
            };
            
            // Overdue Resources Tab
            TabPage tabOverdue = new TabPage("Overdue Resources");
            dgvOverdue = new DataGridView
            {
                Dock = DockStyle.Fill,
                AutoGenerateColumns = true,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect
            };
            tabOverdue.Controls.Add(dgvOverdue);
            
            // Statistics Tab
            TabPage tabStats = new TabPage("Statistics");
            dgvStatistics = new DataGridView
            {
                Dock = DockStyle.Fill,
                AutoGenerateColumns = false,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect
            };
            
            // Setup statistics columns
            dgvStatistics.Columns.Add(new DataGridViewTextBoxColumn
            {
                HeaderText = "Genre",
                DataPropertyName = "Key",
                Width = 200
            });
            
            dgvStatistics.Columns.Add(new DataGridViewTextBoxColumn
            {
                HeaderText = "Count",
                DataPropertyName = "Value",
                Width = 100
            });
            
            tabStats.Controls.Add(dgvStatistics);
            
            tabControl.TabPages.AddRange(new TabPage[] { tabOverdue, tabStats });
            
            this.Controls.Add(tabControl);
        }
        
        private void LoadReports()
        {
            try
            {
                // Load overdue resources
                var overdueResources = _libraryService.GetOverdueResources();
                dgvOverdue.DataSource = overdueResources;
                
                // Load statistics
                var genreStats = _libraryService.GetResourcesByCategory();
                dgvStatistics.DataSource = genreStats.ToList();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading reports: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
