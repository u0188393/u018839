using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace LibraryManagementSystem.Models
{
    public class LibraryResource
    {
        [Key]
        public int Id { get; set; }
        
        [Required]
        [StringLength(200)]
        public string Title { get; set; }
        
        [Required]
        [StringLength(100)]
        public string Author { get; set; }
        
        [Required]
        public int PublicationYear { get; set; }
        
        [Required]
        [StringLength(50)]
        public string Genre { get; set; }
        
        [Required]
        public ResourceType Type { get; set; }
        
        public bool IsAvailable { get; set; } = true;
        
        public DateTime? BorrowedDate { get; set; }
        
        public DateTime? DueDate { get; set; }
        
        [StringLength(100)]
        public string BorrowerName { get; set; }
        
        [StringLength(15)]
        public string BorrowerPhone { get; set; }
        
        public DateTime CreatedDate { get; set; } = DateTime.Now;
        
        public DateTime? UpdatedDate { get; set; }
    }
    
    public enum ResourceType
    {
        Book,
        Journal,
        Media
    }
}
