using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using LibraryManagementSystem.Data;
using LibraryManagementSystem.Models;
using LibraryManagementSystem.DataStructures;

namespace LibraryManagementSystem.Services
{
    public class LibraryService
    {
        private readonly LibraryContext _context;
        private CustomHashTable<int, LibraryResource> _idIndex;
        private BinarySearchTree<string> _titleIndex;
        private BinarySearchTree<string> _authorIndex;
        private CustomHashTable<string, List<LibraryResource>> _genreIndex;
        
        public LibraryService()
        {
            _context = new LibraryContext();
            _idIndex = new CustomHashTable<int, LibraryResource>();
            _titleIndex = new BinarySearchTree<string>();
            _authorIndex = new BinarySearchTree<string>();
            _genreIndex = new CustomHashTable<string, List<LibraryResource>>();
            
            LoadDataIntoIndexes();
        }
        
        // Time Complexity: O(n) - loads all data once
        private void LoadDataIntoIndexes()
        {
            var resources = _context.LibraryResources.ToList();
            
            foreach (var resource in resources)
            {
                _idIndex.Put(resource.Id, resource);
                _titleIndex.Insert(resource.Title.ToLower(), resource);
                _authorIndex.Insert(resource.Author.ToLower(), resource);
                
                if (!_genreIndex.ContainsKey(resource.Genre.ToLower()))
                {
                    _genreIndex.Put(resource.Genre.ToLower(), new List<LibraryResource>());
                }
                _genreIndex.Get(resource.Genre.ToLower()).Add(resource);
            }
        }
        
        // Time Complexity: O(1) database insert + O(1) average case for index updates
        public bool AddResource(LibraryResource resource)
        {
            try
            {
                if (!ValidateResource(resource))
                    return false;
                
                _context.LibraryResources.Add(resource);
                _context.SaveChanges();
                
                // Update indexes
                _idIndex.Put(resource.Id, resource);
                _titleIndex.Insert(resource.Title.ToLower(), resource);
                _authorIndex.Insert(resource.Author.ToLower(), resource);
                
                if (!_genreIndex.ContainsKey(resource.Genre.ToLower()))
                {
                    _genreIndex.Put(resource.Genre.ToLower(), new List<LibraryResource>());
                }
                _genreIndex.Get(resource.Genre.ToLower()).Add(resource);
                
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
        
        // Time Complexity: O(1) average case using hash table
        public LibraryResource GetResourceById(int id)
        {
            try
            {
                return _idIndex.Get(id);
            }
            catch (KeyNotFoundException)
            {
                return null;
            }
        }
        
        // Time Complexity: O(log n) average case using BST
        public List<LibraryResource> SearchByTitle(string title)
        {
            if (string.IsNullOrWhiteSpace(title))
                return new List<LibraryResource>();
            
            return _titleIndex.SearchByPrefix(title.ToLower());
        }
        
        // Time Complexity: O(log n) average case using BST
        public List<LibraryResource> SearchByAuthor(string author)
        {
            if (string.IsNullOrWhiteSpace(author))
                return new List<LibraryResource>();
            
            return _authorIndex.SearchByPrefix(author.ToLower());
        }
        
        // Time Complexity: O(1) average case using hash table
        public List<LibraryResource> SearchByGenre(string genre)
        {
            if (string.IsNullOrWhiteSpace(genre))
                return new List<LibraryResource>();
            
            try
            {
                return _genreIndex.Get(genre.ToLower());
            }
            catch (KeyNotFoundException)
            {
                return new List<LibraryResource>();
            }
        }
        
        public bool UpdateResource(LibraryResource resource)
        {
            try
            {
                if (!ValidateResource(resource))
                    return false;
                
                resource.UpdatedDate = DateTime.Now;
                _context.LibraryResources.Update(resource);
                _context.SaveChanges();
                
                // Reload indexes (in production, you'd want more efficient index updates)
                ReloadIndexes();
                
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
        
        public bool DeleteResource(int id)
        {
            try
            {
                var resource = _context.LibraryResources.Find(id);
                if (resource == null)
                    return false;
                
                _context.LibraryResources.Remove(resource);
                _context.SaveChanges();
                
                ReloadIndexes();
                
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
        
        public bool BorrowResource(int resourceId, string borrowerName, string borrowerPhone, int loanDays = 14)
        {
            try
            {
                var resource = GetResourceById(resourceId);
                if (resource == null || !resource.IsAvailable)
                    return false;
                
                resource.IsAvailable = false;
                resource.BorrowedDate = DateTime.Now;
                resource.DueDate = DateTime.Now.AddDays(loanDays);
                resource.BorrowerName = borrowerName;
                resource.BorrowerPhone = borrowerPhone;
                
                return UpdateResource(resource);
            }
            catch (Exception)
            {
                return false;
            }
        }
        
        public bool ReturnResource(int resourceId)
        {
            try
            {
                var resource = GetResourceById(resourceId);
                if (resource == null || resource.IsAvailable)
                    return false;
                
                resource.IsAvailable = true;
                resource.BorrowedDate = null;
                resource.DueDate = null;
                resource.BorrowerName = null;
                resource.BorrowerPhone = null;
                
                return UpdateResource(resource);
            }
            catch (Exception)
            {
                return false;
            }
        }
        
        public List<LibraryResource> GetOverdueResources()
        {
            return _context.LibraryResources
                .Where(r => !r.IsAvailable && r.DueDate < DateTime.Now)
                .ToList();
        }
        
        public Dictionary<string, int> GetResourcesByCategory()
        {
            return _context.LibraryResources
                .GroupBy(r => r.Genre)
                .ToDictionary(g => g.Key, g => g.Count());
        }
        
        public List<LibraryResource> GetAllResources()
        {
            return _context.LibraryResources.ToList();
        }
        
        private bool ValidateResource(LibraryResource resource)
        {
            if (string.IsNullOrWhiteSpace(resource.Title) ||
                string.IsNullOrWhiteSpace(resource.Author) ||
                string.IsNullOrWhiteSpace(resource.Genre) ||
                resource.PublicationYear < 1000 ||
                resource.PublicationYear > DateTime.Now.Year + 1)
            {
                return false;
            }
            
            return true;
        }
        
        private void ReloadIndexes()
        {
            // Clear existing indexes
            _idIndex = new CustomHashTable<int, LibraryResource>();
            _titleIndex = new BinarySearchTree<string>();
            _authorIndex = new BinarySearchTree<string>();
            _genreIndex = new CustomHashTable<string, List<LibraryResource>>();
            
            // Reload data
            LoadDataIntoIndexes();
        }
        
        public void Dispose()
        {
            _context?.Dispose();
        }
    }
}
