using System;
using System.Collections.Generic;
using LibraryManagementSystem.Models;

namespace LibraryManagementSystem.DataStructures
{
    // Custom Hash Table implementation for O(1) average case search
    public class CustomHashTable<TKey, TValue>
    {
        private class HashNode
        {
            public TKey Key { get; set; }
            public TValue Value { get; set; }
            public HashNode Next { get; set; }
            
            public HashNode(TKey key, TValue value)
            {
                Key = key;
                Value = value;
                Next = null;
            }
        }
        
        private HashNode[] buckets;
        private int capacity;
        private int size;
        private const double LOAD_FACTOR_THRESHOLD = 0.75;
        
        public CustomHashTable(int initialCapacity = 16)
        {
            capacity = initialCapacity;
            buckets = new HashNode[capacity];
            size = 0;
        }
        
        // Time Complexity: O(1) average case, O(n) worst case
        private int GetHash(TKey key)
        {
            return Math.Abs(key.GetHashCode()) % capacity;
        }
        
        // Time Complexity: O(1) average case, O(n) worst case
        public void Put(TKey key, TValue value)
        {
            if ((double)size / capacity >= LOAD_FACTOR_THRESHOLD)
            {
                Resize();
            }
            
            int index = GetHash(key);
            HashNode current = buckets[index];
            
            // Check if key already exists
            while (current != null)
            {
                if (current.Key.Equals(key))
                {
                    current.Value = value;
                    return;
                }
                current = current.Next;
            }
            
            // Add new node at the beginning of the chain
            HashNode newNode = new HashNode(key, value);
            newNode.Next = buckets[index];
            buckets[index] = newNode;
            size++;
        }
        
        // Time Complexity: O(1) average case, O(n) worst case
        public TValue Get(TKey key)
        {
            int index = GetHash(key);
            HashNode current = buckets[index];
            
            while (current != null)
            {
                if (current.Key.Equals(key))
                {
                    return current.Value;
                }
                current = current.Next;
            }
            
            throw new KeyNotFoundException($"Key '{key}' not found");
        }
        
        // Time Complexity: O(1) average case, O(n) worst case
        public bool ContainsKey(TKey key)
        {
            try
            {
                Get(key);
                return true;
            }
            catch (KeyNotFoundException)
            {
                return false;
            }
        }
        
        // Time Complexity: O(n)
        public List<TValue> GetAllValues()
        {
            List<TValue> values = new List<TValue>();
            
            for (int i = 0; i < capacity; i++)
            {
                HashNode current = buckets[i];
                while (current != null)
                {
                    values.Add(current.Value);
                    current = current.Next;
                }
            }
            
            return values;
        }
        
        // Time Complexity: O(n)
        private void Resize()
        {
            HashNode[] oldBuckets = buckets;
            int oldCapacity = capacity;
            
            capacity *= 2;
            buckets = new HashNode[capacity];
            size = 0;
            
            // Rehash all existing elements
            for (int i = 0; i < oldCapacity; i++)
            {
                HashNode current = oldBuckets[i];
                while (current != null)
                {
                    Put(current.Key, current.Value);
                    current = current.Next;
                }
            }
        }
        
        public int Size => size;
        public int Capacity => capacity;
    }
}
