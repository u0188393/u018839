using System;
using System.Collections.Generic;
using LibraryManagementSystem.Models;

namespace LibraryManagementSystem.DataStructures
{
    // Custom Binary Search Tree for sorted data and O(log n) search
    public class BinarySearchTree<T> where T : IComparable<T>
    {
        private class TreeNode
        {
            public T Data { get; set; }
            public List<LibraryResource> Resources { get; set; }
            public TreeNode Left { get; set; }
            public TreeNode Right { get; set; }
            
            public TreeNode(T data)
            {
                Data = data;
                Resources = new List<LibraryResource>();
                Left = null;
                Right = null;
            }
        }
        
        private TreeNode root;
        private int size;
        
        public BinarySearchTree()
        {
            root = null;
            size = 0;
        }
        
        // Time Complexity: O(log n) average case, O(n) worst case
        public void Insert(T key, LibraryResource resource)
        {
            root = InsertRecursive(root, key, resource);
        }
        
        private TreeNode InsertRecursive(TreeNode node, T key, LibraryResource resource)
        {
            if (node == null)
            {
                TreeNode newNode = new TreeNode(key);
                newNode.Resources.Add(resource);
                size++;
                return newNode;
            }
            
            int comparison = key.CompareTo(node.Data);
            
            if (comparison < 0)
            {
                node.Left = InsertRecursive(node.Left, key, resource);
            }
            else if (comparison > 0)
            {
                node.Right = InsertRecursive(node.Right, key, resource);
            }
            else
            {
                // Key already exists, add resource to the list
                node.Resources.Add(resource);
            }
            
            return node;
        }
        
        // Time Complexity: O(log n) average case, O(n) worst case
        public List<LibraryResource> Search(T key)
        {
            TreeNode node = SearchRecursive(root, key);
            return node?.Resources ?? new List<LibraryResource>();
        }
        
        private TreeNode SearchRecursive(TreeNode node, T key)
        {
            if (node == null)
                return null;
            
            int comparison = key.CompareTo(node.Data);
            
            if (comparison == 0)
                return node;
            else if (comparison < 0)
                return SearchRecursive(node.Left, key);
            else
                return SearchRecursive(node.Right, key);
        }
        
        // Time Complexity: O(n)
        public List<LibraryResource> InOrderTraversal()
        {
            List<LibraryResource> result = new List<LibraryResource>();
            InOrderTraversalRecursive(root, result);
            return result;
        }
        
        private void InOrderTraversalRecursive(TreeNode node, List<LibraryResource> result)
        {
            if (node != null)
            {
                InOrderTraversalRecursive(node.Left, result);
                result.AddRange(node.Resources);
                InOrderTraversalRecursive(node.Right, result);
            }
        }
        
        // Time Complexity: O(n)
        public List<LibraryResource> SearchByPrefix(string prefix)
        {
            List<LibraryResource> result = new List<LibraryResource>();
            SearchByPrefixRecursive(root, prefix.ToLower(), result);
            return result;
        }
        
        private void SearchByPrefixRecursive(TreeNode node, string prefix, List<LibraryResource> result)
        {
            if (node == null) return;
            
            string nodeData = node.Data.ToString().ToLower();
            if (nodeData.StartsWith(prefix))
            {
                result.AddRange(node.Resources);
            }
            
            SearchByPrefixRecursive(node.Left, prefix, result);
            SearchByPrefixRecursive(node.Right, prefix, result);
        }
        
        public int Size => size;
    }
}
