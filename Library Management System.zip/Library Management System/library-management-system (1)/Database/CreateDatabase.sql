-- Create Database
CREATE DATABASE LibraryManagementDB;
GO

USE LibraryManagementDB;
GO

-- Create LibraryResources table
CREATE TABLE LibraryResources (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Title NVARCHAR(200) NOT NULL,
    Author NVARCHAR(100) NOT NULL,
    PublicationYear INT NOT NULL,
    Genre NVARCHAR(50) NOT NULL,
    Type INT NOT NULL, -- 0=Book, 1=Journal, 2=Media
    IsAvailable BIT NOT NULL DEFAULT 1,
    BorrowedDate DATETIME2 NULL,
    DueDate DATETIME2 NULL,
    BorrowerName NVARCHAR(100) NULL,
    BorrowerPhone NVARCHAR(15) NULL,
    CreatedDate DATETIME2 NOT NULL DEFAULT GETDATE(),
    UpdatedDate DATETIME2 NULL
);

-- Create indexes for better search performance
CREATE INDEX IX_LibraryResources_Title ON LibraryResources(Title);
CREATE INDEX IX_LibraryResources_Author ON LibraryResources(Author);
CREATE INDEX IX_LibraryResources_Genre ON LibraryResources(Genre);
CREATE INDEX IX_LibraryResources_IsAvailable ON LibraryResources(IsAvailable);
CREATE INDEX IX_LibraryResources_DueDate ON LibraryResources(DueDate);

-- Insert sample data
INSERT INTO LibraryResources (Title, Author, PublicationYear, Genre, Type, IsAvailable)
VALUES 
    ('The Great Gatsby', 'F. Scott Fitzgerald', 1925, 'Fiction', 0, 1),
    ('To Kill a Mockingbird', 'Harper Lee', 1960, 'Fiction', 0, 1),
    ('1984', 'George Orwell', 1949, 'Dystopian Fiction', 0, 1),
    ('Pride and Prejudice', 'Jane Austen', 1813, 'Romance', 0, 1),
    ('The Catcher in the Rye', 'J.D. Salinger', 1951, 'Fiction', 0, 1),
    ('Scientific American', 'Various Authors', 2023, 'Science', 1, 1),
    ('National Geographic', 'Various Authors', 2023, 'Geography', 1, 1),
    ('The Godfather', 'Francis Ford Coppola', 1972, 'Drama', 2, 1),
    ('Casablanca', 'Michael Curtiz', 1942, 'Romance', 2, 1),
    ('The Beatles Abbey Road', 'The Beatles', 1969, 'Music', 2, 1);

-- Create stored procedures for common operations
GO

CREATE PROCEDURE sp_GetOverdueResources
AS
BEGIN
    SELECT * FROM LibraryResources 
    WHERE IsAvailable = 0 AND DueDate < GETDATE()
    ORDER BY DueDate;
END
GO

CREATE PROCEDURE sp_GetResourcesByGenre
AS
BEGIN
    SELECT Genre, COUNT(*) as ResourceCount
    FROM LibraryResources
    GROUP BY Genre
    ORDER BY ResourceCount DESC;
END
GO

CREATE PROCEDURE sp_GetBorrowingStatistics
AS
BEGIN
    SELECT 
        COUNT(*) as TotalResources,
        SUM(CASE WHEN IsAvailable = 1 THEN 1 ELSE 0 END) as AvailableResources,
        SUM(CASE WHEN IsAvailable = 0 THEN 1 ELSE 0 END) as BorrowedResources,
        SUM(CASE WHEN IsAvailable = 0 AND DueDate < GETDATE() THEN 1 ELSE 0 END) as OverdueResources
    FROM LibraryResources;
END
GO
