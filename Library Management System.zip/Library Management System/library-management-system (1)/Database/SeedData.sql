-- Additional seed data for testing
USE LibraryManagementDB;
GO

-- Insert more sample data for comprehensive testing
INSERT INTO LibraryResources (Title, Author, PublicationYear, Genre, Type, IsAvailable)
VALUES 
    ('Dune', 'Frank Herbert', 1965, 'Science Fiction', 0, 1),
    ('The Lord of the Rings', 'J.R.R. Tolkien', 1954, 'Fantasy', 0, 1),
    ('Harry Potter and the Sorcerer''s Stone', 'J.K. Rowling', 1997, 'Fantasy', 0, 0),
    ('The Hobbit', 'J.R.R. Tolkien', 1937, 'Fantasy', 0, 1),
    ('Brave New World', 'Aldous Huxley', 1932, 'Dystopian Fiction', 0, 1),
    ('The Martian', 'Andy Weir', 2011, 'Science Fiction', 0, 1),
    ('Nature Magazine', 'Various Authors', 2023, 'Science', 1, 1),
    ('Time Magazine', 'Various Authors', 2023, 'News', 1, 0),
    ('The Shawshank Redemption', 'Frank Darabont', 1994, 'Drama', 2, 1),
    ('Inception', 'Christopher Nolan', 2010, 'Sci-Fi', 2, 1),
    ('The Dark Knight', 'Christopher Nolan', 2008, 'Action', 2, 0),
    ('Pulp Fiction', 'Quentin Tarantino', 1994, 'Crime', 2, 1);

-- Update some resources to be borrowed (for testing overdue functionality)
UPDATE LibraryResources 
SET IsAvailable = 0, 
    BorrowedDate = DATEADD(day, -20, GETDATE()), 
    DueDate = DATEADD(day, -6, GETDATE()),
    BorrowerName = 'John Smith',
    BorrowerPhone = '555-0123'
WHERE Title = 'Harry Potter and the Sorcerer''s Stone';

UPDATE LibraryResources 
SET IsAvailable = 0, 
    BorrowedDate = DATEADD(day, -10, GETDATE()), 
    DueDate = DATEADD(day, 4, GETDATE()),
    BorrowerName = 'Jane Doe',
    BorrowerPhone = '555-0456'
WHERE Title = 'Time Magazine';

UPDATE LibraryResources 
SET IsAvailable = 0, 
    BorrowedDate = DATEADD(day, -25, GETDATE()), 
    DueDate = DATEADD(day, -11, GETDATE()),
    BorrowerName = 'Bob Johnson',
    BorrowerPhone = '555-0789'
WHERE Title = 'The Dark Knight';
